# Engineering Analytics — Visão Geral

Projeto com **Angular 18** (frontend) e **Spring Boot 3** (backend) que replica a tela
"Visão Geral" e busca os dados reais do **SonarQube** e **Jenkins**.

## Estrutura

```
engineering-analytics/
├── backend/    Spring Boot (Java 17) — agrega dados do Sonar e Jenkins
└── frontend/   Angular 18 (standalone) — tela do dashboard
```

## Rodando com mock do Sonar e do Jenkins (sem precisar de instâncias reais)

O projeto inclui mocks do SonarQube (`mock-sonar/`) e do Jenkins (`mock-jenkins/`).
Ambos usam só a stdlib do Python (zero dependências) e respondem nos mesmos formatos
que `SonarClient.java` e `JenkinsClient.java` já consomem.

**Sonar mock** — `GET /api/projects/search`, `/api/measures/component`,
`/api/issues/search`, `/api/measures/search_history`. Gera 148 projetos fake batendo
com os números do dashboard de exemplo (12,8M linhas, 82,4% cobertura, 23
vulnerabilidades, 47 issues críticas).

**Jenkins mock** — `GET /api/json`, `/job/{jobName}/api/json`, `/queue/api/json`.
Gera 8 jobs com ~1.600 builds distribuídos ao longo de 12 meses (mesma curva do
gráfico "Releases por mês"), com 7 falhas e 5 builds instáveis espalhados aleatoriamente.

1. Suba os dois mocks (em terminais separados):

   ```bash
   cd mock-sonar && python3 sonar_mock_server.py 9001
   cd mock-jenkins && python3 jenkins_mock_server.py 9002
   ```

2. Rode o backend com o profile `mock` (já aponta Sonar e Jenkins para os mocks):

   ```bash
   cd backend
   ./mvnw spring-boot:run -Dspring-boot.run.profiles=mock
   ```

3. Testa:

   ```bash
   curl http://localhost:8080/api/dashboard/overview
   curl http://localhost:8080/api/dashboard/releases
   ```

   Nenhuma dependência externa é necessária — tudo roda localmente.

## Persistindo o histórico em Oracle (opcional)

Sonar e Jenkins não guardam histórico confiável para sempre (retenção configurável,
jobs de limpeza, etc.). Para ter métricas confiáveis ao longo do tempo — e não
sobrecarregar Sonar/Jenkins a cada refresh de tela — o backend pode gravar
snapshots periódicos em um banco Oracle e servir o dashboard a partir de lá.

**Como funciona:**

- Um coletor (`CollectorService`) roda todo dia às 2h (cron configurável) e também
  pode ser disparado na hora via `POST /api/collector/run`. Ele reaproveita os
  mesmos `SonarService`/`JenkinsService` já usados no modo "ao vivo" — não é um
  caminho de código separado, é o mesmo, só que persistindo o resultado.
- Duas tabelas: `project_metrics_snapshot` (uma foto por projeto a cada coleta —
  permite ver cobertura/débito técnico evoluindo) e `build_snapshot` (um build do
  Jenkins por linha, sem duplicar graças à constraint única `job_name + build_number`).
- Os endpoints `/api/dashboard/overview` e `/api/dashboard/releases` ganham o
  parâmetro `source`:
  - `source=live` (padrão) — comportamento de sempre, bate direto no Sonar/Jenkins
  - `source=db` — monta a mesma resposta a partir do que está salvo no Oracle

Isso tudo só é ativado com o profile `oracle` — sem esse profile, a aplicação nem
tenta abrir conexão com banco nenhum (zero impacto se você não for usar).

**Para rodar:**

1. Sobe um Oracle (ex: `gvenzl/oracle-xe` via Docker, se não tiver um à mão):

   ```bash
   docker run -d --name oracle-xe -p 1521:1521 -e ORACLE_PASSWORD=changeit gvenzl/oracle-xe:21-slim
   ```

2. Configura as variáveis de ambiente (ou edita `application-oracle.yml` direto):

   ```bash
   export ORACLE_HOST=localhost
   export ORACLE_PORT=1521
   export ORACLE_SERVICE=XEPDB1
   export ORACLE_USER=engineering_analytics
   export ORACLE_PASSWORD=changeit
   ```

3. Sobe o backend combinando os profiles (`mock` para Sonar/Jenkins + `oracle` para persistência):

   ```bash
   ./mvnw spring-boot:run -Dspring-boot.run.profiles=mock,oracle
   ```

   Por padrão o Hibernate cria as tabelas sozinho (`ddl-auto: update`). Se preferir
   controle explícito do schema, rode `backend/src/main/resources/schema-oracle.sql`
   manualmente e troque `ddl-auto` para `validate`.

4. Dispara a primeira coleta manualmente (não precisa esperar até 2h da manhã):

   ```bash
   curl -X POST http://localhost:8080/api/collector/run
   ```

5. Testa lendo do banco:

   ```bash
   curl "http://localhost:8080/api/dashboard/overview?source=db"
   curl "http://localhost:8080/api/dashboard/releases?source=db"
   ```

**Limitações conhecidas (transparência, não escondendo debaixo do tapete):**

- O total de "issues críticas" no modo `source=db` é uma aproximação (bugs + code
  smells), porque hoje só persistimos as métricas por projeto — o número exato vem
  de uma consulta separada (`/api/issues/search`) no Sonar ao vivo que não está
  sendo salva ainda. Dá para adicionar uma tabela `issue_snapshot` se precisar do
  valor exato no histórico.
- `ddl-auto: update` é conveniente para rodar o exemplo, mas em produção o ideal é
  gerenciar o schema com Flyway/Liquibase e usar `ddl-auto: validate`.
- O coletor grava por nome do projeto (não pela key real do Sonar) por simplicidade
  — se dois projetos puderem ter o mesmo nome, ajuste `CollectorService` para usar
  a key de verdade.

## Backend

1. Configure as credenciais em `backend/src/main/resources/application.yml`
   (ou via variáveis de ambiente `SONAR_TOKEN`, `JENKINS_USER`, `JENKINS_API_TOKEN`):

   ```yaml
   integrations:
     sonar:
       url: https://sonar.suaempresa.com
       token: ${SONAR_TOKEN}
     jenkins:
       url: https://jenkins.suaempresa.com
       user: ${JENKINS_USER}
       api-token: ${JENKINS_API_TOKEN}
   ```

2. Rodar:

   ```bash
   cd backend
   ./mvnw spring-boot:run
   ```

   API disponível em `http://localhost:8080`.

### Endpoints

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/dashboard/overview` | Payload completo da tela (KPIs, gráficos, tabela, rodapé) |
| GET | `/api/dashboard/lines-evolution?projectKey=X&from=2024-06-01` | Série histórica de linhas de código |

Os dados são cacheados por 2 minutos (Caffeine) para não sobrecarregar Sonar/Jenkins.

## Frontend

```bash
cd frontend
npm install
npm start
```

Acesse `http://localhost:4200`. A URL da API é configurada em
`frontend/src/environments/environment.ts` (`apiUrl`).

## Pontos de atenção / próximos passos

- O gráfico "Evolução das linhas de código" precisa de um `projectKey` de referência
  (ou agregação própria) — hoje o endpoint `/lines-evolution` está separado do `/overview`
  para você escolher o projeto/portfólio certo.
- O token do Sonar precisa de permissão de leitura em **Browse** e **Execute Analysis**
  nos projetos; o token do Jenkins precisa de permissão de leitura nos jobs.
- Ajuste o `integrations.jenkins.view` caso queira restringir a uma pasta/view específica.
- CORS já libera `http://localhost:4200`; altere `integrations.allowed-origin` em produção.
