package com.analytics.engineering.persistence.repository;

import com.analytics.engineering.persistence.entity.BuildSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;

public interface BuildSnapshotRepository extends JpaRepository<BuildSnapshot, Long> {

    boolean existsByJobNameAndBuildNumber(String jobName, int buildNumber);

    List<BuildSnapshot> findByBuildTimestampBetween(Instant from, Instant to);

    List<BuildSnapshot> findAllByOrderByBuildTimestampDesc();
}
