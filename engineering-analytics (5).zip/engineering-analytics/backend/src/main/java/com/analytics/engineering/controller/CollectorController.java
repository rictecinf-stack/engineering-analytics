package com.analytics.engineering.controller;

import com.analytics.engineering.service.CollectorService;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Dispara a coleta de métricas (Sonar + Jenkins -> Oracle) sob demanda, sem
 * esperar o agendamento (cron padrão: todo dia às 2h). Útil para testes e demos.
 * Só existe quando o profile "oracle" está ativo.
 */
@RestController
@RequestMapping("/api/collector")
@Profile("oracle")
public class CollectorController {

    private final CollectorService collectorService;

    public CollectorController(CollectorService collectorService) {
        this.collectorService = collectorService;
    }

    @PostMapping("/run")
    public Map<String, Object> runNow() {
        int projects = collectorService.collectSonarSnapshots();
        int builds = collectorService.collectJenkinsBuilds();
        return Map.of(
                "projectsCollected", projects,
                "buildsInserted", builds,
                "message", "Coleta concluída. Use ?source=db nos endpoints do dashboard para ler esses dados."
        );
    }
}
