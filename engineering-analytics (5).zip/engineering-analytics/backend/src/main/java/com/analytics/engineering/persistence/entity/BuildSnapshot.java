package com.analytics.engineering.persistence.entity;

import jakarta.persistence.*;

import java.time.Instant;
import java.time.OffsetDateTime;

/**
 * Um build/release do Jenkins persistido. Diferente do snapshot de projeto
 * (que é uma foto recorrente), aqui cada build é gravado uma única vez —
 * o coletor usa (job_name, build_number) como chave natural para não duplicar.
 */
@Entity
@Table(
        name = "build_snapshot",
        uniqueConstraints = @UniqueConstraint(name = "uq_build_job_number", columnNames = {"job_name", "build_number"}),
        indexes = @Index(name = "idx_build_timestamp", columnList = "build_timestamp")
)
public class BuildSnapshot {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "build_seq")
    @SequenceGenerator(name = "build_seq", sequenceName = "build_snapshot_seq", allocationSize = 50)
    private Long id;

    @Column(name = "job_name", nullable = false, length = 200)
    private String jobName;

    @Column(name = "build_number", nullable = false)
    private int buildNumber;

    @Column(name = "build_timestamp", nullable = false)
    private Instant buildTimestamp;

    @Column(name = "result", nullable = false, length = 20)
    private String result; // SUCCESS | FAILURE | UNSTABLE

    @Column(name = "duration_ms", nullable = false)
    private long durationMs;

    @Column(name = "environment", nullable = false, length = 30)
    private String environment; // production | staging

    @Column(name = "collected_at", nullable = false)
    private OffsetDateTime collectedAt;

    protected BuildSnapshot() {
        // exigido pelo JPA
    }

    public BuildSnapshot(String jobName, int buildNumber, Instant buildTimestamp, String result,
                          long durationMs, String environment, OffsetDateTime collectedAt) {
        this.jobName = jobName;
        this.buildNumber = buildNumber;
        this.buildTimestamp = buildTimestamp;
        this.result = result;
        this.durationMs = durationMs;
        this.environment = environment;
        this.collectedAt = collectedAt;
    }

    public Long getId() { return id; }
    public String getJobName() { return jobName; }
    public int getBuildNumber() { return buildNumber; }
    public Instant getBuildTimestamp() { return buildTimestamp; }
    public String getResult() { return result; }
    public long getDurationMs() { return durationMs; }
    public String getEnvironment() { return environment; }
    public OffsetDateTime getCollectedAt() { return collectedAt; }
}
