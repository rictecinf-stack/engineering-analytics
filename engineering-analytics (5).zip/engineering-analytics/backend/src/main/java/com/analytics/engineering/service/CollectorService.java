package com.analytics.engineering.service;

import com.analytics.engineering.persistence.entity.BuildSnapshot;
import com.analytics.engineering.persistence.entity.ProjectMetricsSnapshot;
import com.analytics.engineering.persistence.repository.BuildSnapshotRepository;
import com.analytics.engineering.persistence.repository.ProjectMetricsSnapshotRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

/**
 * Busca os dados ao vivo no Sonar/Jenkins (reaproveitando SonarService/JenkinsService)
 * e grava no Oracle. Roda automaticamente pelo cron configurado, e também pode ser
 * disparado manualmente via POST /api/collector/run (ver CollectorController) —
 * útil para não esperar o agendamento durante testes/demos.
 *
 * Só existe quando o profile "oracle" está ativo.
 */
@Service
@Profile("oracle")
public class CollectorService {

    private static final Logger log = LoggerFactory.getLogger(CollectorService.class);

    private static final Map<String, String> SONAR_KEY_TO_PRETTY = Map.of(
            "java", "Java",
            "js", "JavaScript",
            "ts", "TypeScript",
            "py", "Python",
            "sql", "SQL"
    );

    private final SonarService sonarService;
    private final JenkinsService jenkinsService;
    private final ProjectMetricsSnapshotRepository projectRepository;
    private final BuildSnapshotRepository buildRepository;

    public CollectorService(
            SonarService sonarService,
            JenkinsService jenkinsService,
            ProjectMetricsSnapshotRepository projectRepository,
            BuildSnapshotRepository buildRepository
    ) {
        this.sonarService = sonarService;
        this.jenkinsService = jenkinsService;
        this.projectRepository = projectRepository;
        this.buildRepository = buildRepository;
    }

    /** Roda todo dia às 2h da manhã por padrão; ajuste em application.yml (collector.cron). */
    @Scheduled(cron = "${collector.cron:0 0 2 * * *}")
    public void runScheduled() {
        log.info("Iniciando coleta agendada de métricas (Sonar + Jenkins) para o Oracle");
        int projectCount = collectSonarSnapshots();
        int buildCount = collectJenkinsBuilds();
        log.info("Coleta concluída: {} projetos, {} builds novos", projectCount, buildCount);
    }

    /** Grava uma foto atual de cada projeto do Sonar. Chamado pelo agendamento ou manualmente. */
    public int collectSonarSnapshots() {
        List<SonarService.ProjectMetrics> projects = sonarService.fetchProjectMetrics().block();
        if (projects == null || projects.isEmpty()) return 0;

        OffsetDateTime now = OffsetDateTime.now();
        int count = 0;
        for (SonarService.ProjectMetrics p : projects) {
            String language = mainLanguage(p.languageDistribution());
            ProjectMetricsSnapshot snapshot = new ProjectMetricsSnapshot(
                    p.name(), // usamos o nome como chave por simplicidade; troque para a key real do Sonar se precisar de unicidade rígida
                    p.name(),
                    language,
                    (long) p.linesOfCode(),
                    p.coverage(),
                    p.duplicationDensity(),
                    p.technicalDebtMinutes(),
                    p.vulnerabilities(),
                    p.bugs(),
                    p.codeSmells(),
                    now
            );
            projectRepository.save(snapshot);
            count++;
        }
        return count;
    }

    /** Grava só os builds do Jenkins que ainda não existem no banco (idempotente). */
    public int collectJenkinsBuilds() {
        JenkinsService.BuildStats stats = jenkinsService.fetchBuildStats().block();
        if (stats == null) return 0;

        OffsetDateTime now = OffsetDateTime.now();
        int inserted = 0;
        for (JenkinsService.BuildEntry b : stats.allBuilds()) {
            if (buildRepository.existsByJobNameAndBuildNumber(b.jobName(), b.number())) {
                continue; // já coletado antes, não duplica
            }
            BuildSnapshot snapshot = new BuildSnapshot(
                    b.jobName(),
                    b.number(),
                    b.timestamp(),
                    b.result(),
                    b.durationMs(),
                    b.environment(),
                    now
            );
            buildRepository.save(snapshot);
            inserted++;
        }
        return inserted;
    }

    private String mainLanguage(String distribution) {
        if (distribution == null || distribution.isBlank()) return "Outros";
        String[] parts = distribution.split("=");
        return SONAR_KEY_TO_PRETTY.getOrDefault(parts[0], "Outros");
    }
}
