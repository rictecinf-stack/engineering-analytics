package com.analytics.engineering.service;

import com.analytics.engineering.dto.DashboardOverviewResponse;
import com.analytics.engineering.dto.DashboardOverviewResponse.KpiValue;
import com.analytics.engineering.dto.DashboardOverviewResponse.ReleaseRow;
import com.analytics.engineering.dto.ReleasesOverviewResponse;
import com.analytics.engineering.persistence.entity.BuildSnapshot;
import com.analytics.engineering.persistence.entity.ProjectMetricsSnapshot;
import com.analytics.engineering.persistence.repository.BuildSnapshotRepository;
import com.analytics.engineering.persistence.repository.ProjectMetricsSnapshotRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Reconstrói exatamente os mesmos DTOs que o DashboardService monta ao vivo,
 * mas lendo do Oracle em vez de bater no Sonar/Jenkins. Usado quando a
 * requisição pede ?source=db — útil para: (1) não sobrecarregar Sonar/Jenkins
 * a cada refresh de tela, (2) ter histórico confiável mesmo que Sonar/Jenkins
 * já tenham descartado dados antigos, (3) funcionar mesmo se Sonar/Jenkins
 * estiverem fora do ar no momento da consulta.
 *
 * Só é registrado como bean quando o profile "oracle" está ativo — sem esse
 * profile, a aplicação nem tenta abrir conexão com banco nenhum.
 */
@Service
@Profile("oracle")
public class DashboardHistoryService {

    private static final Map<String, String> PRETTY_TO_SONAR_KEY = Map.of(
            "Java", "java",
            "JavaScript", "js",
            "TypeScript", "ts",
            "Python", "py",
            "SQL", "sql",
            "Outros", "outros"
    );

    private final ProjectMetricsSnapshotRepository projectRepository;
    private final BuildSnapshotRepository buildRepository;
    private final DashboardService dashboardService;
    private final JenkinsService jenkinsService;

    public DashboardHistoryService(
            ProjectMetricsSnapshotRepository projectRepository,
            BuildSnapshotRepository buildRepository,
            DashboardService dashboardService,
            JenkinsService jenkinsService
    ) {
        this.projectRepository = projectRepository;
        this.buildRepository = buildRepository;
        this.dashboardService = dashboardService;
        this.jenkinsService = jenkinsService;
    }

    public DashboardOverviewResponse buildOverviewFromDb(LocalDate from, LocalDate to, List<String> technologies) {
        List<SonarService.ProjectMetrics> projects = projectRepository.findLatestSnapshotPerProject().stream()
                .map(this::toProjectMetrics)
                .filter(p -> technologies == null || technologies.isEmpty()
                        || technologies.contains(prettyLanguageFromDistribution(p.languageDistribution())))
                .collect(Collectors.toList());

        int vulnerabilities = projects.stream().mapToInt(SonarService.ProjectMetrics::vulnerabilities).sum();
        // "Issues críticas" não tem uma coluna própria persistida (é uma consulta agregada
        // separada no Sonar ao vivo); aproximamos aqui por bugs + code smells como um proxy —
        // vale criar uma tabela própria de snapshot de issues se precisar do número exato.
        int criticalIssuesApprox = projects.stream()
                .mapToInt(p -> p.bugs() + Math.min(p.codeSmells(), 5))
                .sum();

        List<BuildSnapshot> buildRows = buildRepository.findAllByOrderByBuildTimestampDesc();
        List<JenkinsService.BuildEntry> entries = buildRows.stream()
                .filter(b -> withinRange(b.getBuildTimestamp(), from, to))
                .map(this::toBuildEntry)
                .toList();
        JenkinsService.BuildStats stats = jenkinsService.aggregate(entries);

        return dashboardService.assemble(projects, vulnerabilities, criticalIssuesApprox, stats);
    }

    public ReleasesOverviewResponse buildReleasesFromDb(int limit, LocalDate from, LocalDate to, String environment) {
        List<JenkinsService.BuildEntry> entries = buildRepository.findAllByOrderByBuildTimestampDesc().stream()
                .filter(b -> withinRange(b.getBuildTimestamp(), from, to))
                .filter(b -> environment == null || environment.isBlank() || environment.equalsIgnoreCase(b.getEnvironment()))
                .map(this::toBuildEntry)
                .toList();

        JenkinsService.BuildStats stats = jenkinsService.aggregate(entries);
        long total = stats.totalReleases();
        long failed = stats.deployFailures();
        double successRate = total == 0 ? 0 : (100.0 * (total - failed) / total);

        List<ReleaseRow> rows = stats.allBuilds().stream()
                .limit(limit)
                .map(dashboardService::toReleaseRow)
                .collect(Collectors.toList());

        return new ReleasesOverviewResponse(
                new KpiValue(String.valueOf(total), "no histórico (Oracle)", "flat"),
                new KpiValue(String.format(Locale.forLanguageTag("pt-BR"), "%.1f%%", successRate), "no histórico (Oracle)", "flat"),
                new KpiValue(String.format(Locale.forLanguageTag("pt-BR"), "%.1f dias", stats.averageLeadTimeDays()), "no histórico (Oracle)", "flat"),
                new KpiValue(String.valueOf(failed), "no histórico (Oracle)", "flat"),
                stats.releasesPerMonth(),
                rows
        );
    }

    private boolean withinRange(Instant timestamp, LocalDate from, LocalDate to) {
        LocalDate date = timestamp.atZone(ZoneId.systemDefault()).toLocalDate();
        if (from != null && date.isBefore(from)) return false;
        if (to != null && date.isAfter(to)) return false;
        return true;
    }

    private SonarService.ProjectMetrics toProjectMetrics(ProjectMetricsSnapshot row) {
        String sonarKey = PRETTY_TO_SONAR_KEY.getOrDefault(row.getLanguage(), "outros");
        String languageDistribution = sonarKey + "=" + row.getNcloc();
        return new SonarService.ProjectMetrics(
                row.getProjectName(),
                row.getCoverage(),
                row.getNcloc(),
                languageDistribution,
                row.getDuplicationDensity(),
                row.getTechnicalDebtMinutes(),
                row.getVulnerabilities(),
                row.getBugs(),
                row.getCodeSmells()
        );
    }

    private JenkinsService.BuildEntry toBuildEntry(BuildSnapshot row) {
        return new JenkinsService.BuildEntry(
                row.getJobName(),
                row.getBuildNumber(),
                row.getBuildTimestamp(),
                row.getResult(),
                row.getDurationMs(),
                row.getEnvironment()
        );
    }

    private String prettyLanguageFromDistribution(String distribution) {
        String[] parts = distribution.split("=");
        String sonarKey = parts[0];
        return PRETTY_TO_SONAR_KEY.entrySet().stream()
                .filter(e -> e.getValue().equals(sonarKey))
                .map(Map.Entry::getKey)
                .findFirst()
                .orElse("Outros");
    }
}
