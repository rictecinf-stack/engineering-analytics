package com.analytics.engineering.controller;

import com.analytics.engineering.dto.DashboardOverviewResponse;
import com.analytics.engineering.dto.DashboardOverviewResponse.ChartPoint;
import com.analytics.engineering.dto.ReleasesOverviewResponse;
import com.analytics.engineering.service.DashboardHistoryService;
import com.analytics.engineering.service.DashboardService;
import com.analytics.engineering.service.SonarService;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;
    private final SonarService sonarService;
    /** Só existe quando o profile "oracle" está ativo; Optional evita erro de startup sem ele. */
    private final Optional<DashboardHistoryService> dashboardHistoryService;

    public DashboardController(
            DashboardService dashboardService,
            SonarService sonarService,
            Optional<DashboardHistoryService> dashboardHistoryService
    ) {
        this.dashboardService = dashboardService;
        this.sonarService = sonarService;
        this.dashboardHistoryService = dashboardHistoryService;
    }

    /**
     * Payload consumido pela tela "Visão Geral" (KPIs, gráficos, tabela de tecnologias, rodapé).
     *
     * @param from          data inicial do filtro de período (ISO yyyy-MM-dd), opcional
     * @param to            data final do filtro de período (ISO yyyy-MM-dd), opcional
     * @param technologies  lista de tecnologias separadas por vírgula (ex: "Java,Python"), opcional
     * @param source        "live" (padrão, bate direto no Sonar/Jenkins) ou "db" (lê do Oracle,
     *                      exige profile "oracle" ativo e a coleta já ter rodado pelo menos uma vez)
     */
    @GetMapping("/overview")
    public Mono<DashboardOverviewResponse> overview(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String technologies,
            @RequestParam(defaultValue = "live") String source
    ) {
        LocalDate fromDate = parseDate(from);
        LocalDate toDate = parseDate(to);
        List<String> techList = parseList(technologies);

        if ("db".equalsIgnoreCase(source)) {
            DashboardHistoryService historyService = dashboardHistoryService.orElseThrow(() ->
                    new IllegalStateException("source=db requer o profile \"oracle\" ativo (-Dspring-boot.run.profiles=oracle)"));
            return Mono.fromCallable(() -> historyService.buildOverviewFromDb(fromDate, toDate, techList))
                    .subscribeOn(Schedulers.boundedElastic());
        }

        return dashboardService.buildOverview(fromDate, toDate, techList);
    }

    /**
     * Payload consumido pela tela "Releases" (KPIs, gráfico mensal e lista de builds).
     *
     * @param environment "production" | "staging", opcional (todos por padrão)
     * @param source      "live" (padrão) ou "db" (lê do Oracle)
     */
    @GetMapping("/releases")
    public Mono<ReleasesOverviewResponse> releases(
            @RequestParam(defaultValue = "50") int limit,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String environment,
            @RequestParam(defaultValue = "live") String source
    ) {
        LocalDate fromDate = parseDate(from);
        LocalDate toDate = parseDate(to);

        if ("db".equalsIgnoreCase(source)) {
            DashboardHistoryService historyService = dashboardHistoryService.orElseThrow(() ->
                    new IllegalStateException("source=db requer o profile \"oracle\" ativo (-Dspring-boot.run.profiles=oracle)"));
            return Mono.fromCallable(() -> historyService.buildReleasesFromDb(limit, fromDate, toDate, environment))
                    .subscribeOn(Schedulers.boundedElastic());
        }

        return dashboardService.buildReleasesOverview(limit, fromDate, toDate, environment);
    }

    /** Série histórica de linhas de código para o gráfico "Evolução das linhas de código". */
    @GetMapping("/lines-evolution")
    public Mono<List<ChartPoint>> linesEvolution(
            @RequestParam String projectKey,
            @RequestParam(defaultValue = "2024-06-01") String from
    ) {
        return sonarService.linesOfCodeEvolution(projectKey, from);
    }

    private LocalDate parseDate(String value) {
        if (value == null || value.isBlank()) return null;
        return LocalDate.parse(value);
    }

    private List<String> parseList(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        return Arrays.stream(csv.split(",")).map(String::trim).filter(s -> !s.isEmpty()).toList();
    }
}
