package com.analytics.engineering.persistence.repository;

import com.analytics.engineering.persistence.entity.ProjectMetricsSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProjectMetricsSnapshotRepository extends JpaRepository<ProjectMetricsSnapshot, Long> {

    /**
     * Retorna só a foto mais recente de cada projeto (não o histórico inteiro) —
     * é isso que o dashboard usa para montar os KPIs "atuais" a partir do banco.
     */
    @Query(value = """
            SELECT s.* FROM project_metrics_snapshot s
            INNER JOIN (
                SELECT project_key, MAX(collected_at) AS max_collected_at
                FROM project_metrics_snapshot
                GROUP BY project_key
            ) latest
            ON s.project_key = latest.project_key
            AND s.collected_at = latest.max_collected_at
            """, nativeQuery = true)
    List<ProjectMetricsSnapshot> findLatestSnapshotPerProject();

    /** Histórico completo de um projeto (para gráficos de evolução ao longo do tempo). */
    List<ProjectMetricsSnapshot> findByProjectKeyOrderByCollectedAtAsc(String projectKey);
}
