package com.analytics.engineering.persistence.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * Uma "foto" das métricas de um projeto do Sonar em um determinado momento.
 * O coletor grava uma linha nova por projeto a cada execução — isso é o que
 * permite reconstruir histórico (ex: cobertura ao longo do tempo) mesmo que
 * o Sonar em si não guarde esse histórico por muito tempo.
 */
@Entity
@Table(name = "project_metrics_snapshot", indexes = {
        @Index(name = "idx_pms_project_key", columnList = "project_key"),
        @Index(name = "idx_pms_collected_at", columnList = "collected_at")
})
public class ProjectMetricsSnapshot {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_seq")
    @SequenceGenerator(name = "pms_seq", sequenceName = "project_metrics_snapshot_seq", allocationSize = 50)
    private Long id;

    @Column(name = "project_key", nullable = false, length = 200)
    private String projectKey;

    @Column(name = "project_name", nullable = false, length = 200)
    private String projectName;

    @Column(name = "language", nullable = false, length = 30)
    private String language; // valor "bonito": Java, TypeScript, JavaScript, Python, SQL, Outros

    @Column(name = "ncloc", nullable = false)
    private long ncloc;

    @Column(name = "coverage", nullable = false)
    private double coverage;

    @Column(name = "duplication_density", nullable = false)
    private double duplicationDensity;

    @Column(name = "technical_debt_minutes", nullable = false)
    private long technicalDebtMinutes;

    @Column(name = "vulnerabilities", nullable = false)
    private int vulnerabilities;

    @Column(name = "bugs", nullable = false)
    private int bugs;

    @Column(name = "code_smells", nullable = false)
    private int codeSmells;

    @Column(name = "collected_at", nullable = false)
    private OffsetDateTime collectedAt;

    protected ProjectMetricsSnapshot() {
        // exigido pelo JPA
    }

    public ProjectMetricsSnapshot(String projectKey, String projectName, String language, long ncloc,
                                   double coverage, double duplicationDensity, long technicalDebtMinutes,
                                   int vulnerabilities, int bugs, int codeSmells, OffsetDateTime collectedAt) {
        this.projectKey = projectKey;
        this.projectName = projectName;
        this.language = language;
        this.ncloc = ncloc;
        this.coverage = coverage;
        this.duplicationDensity = duplicationDensity;
        this.technicalDebtMinutes = technicalDebtMinutes;
        this.vulnerabilities = vulnerabilities;
        this.bugs = bugs;
        this.codeSmells = codeSmells;
        this.collectedAt = collectedAt;
    }

    public Long getId() { return id; }
    public String getProjectKey() { return projectKey; }
    public String getProjectName() { return projectName; }
    public String getLanguage() { return language; }
    public long getNcloc() { return ncloc; }
    public double getCoverage() { return coverage; }
    public double getDuplicationDensity() { return duplicationDensity; }
    public long getTechnicalDebtMinutes() { return technicalDebtMinutes; }
    public int getVulnerabilities() { return vulnerabilities; }
    public int getBugs() { return bugs; }
    public int getCodeSmells() { return codeSmells; }
    public OffsetDateTime getCollectedAt() { return collectedAt; }
}
